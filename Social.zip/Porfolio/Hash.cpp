class HashTable {

private:

struct Node {
       Bid bid;
       unsigned key;
       Node* nextNodePtr;

       // constructor
       Node() {
           key = UINT_MAX;
           nextNodePtr = nullptr;
       }

       // Node initialized with a bid
       Node(Bid myBid) : Node() {
           bid = myBid;
       }

       Node(Bid myBid, unsigned newKey) : Node(myBid) {
           key = newKey;
       }
   };

   vector<Node> myNodes;

   unsigned setSize = DEFAULT_SIZE;

    unsigned int hash(int key);

public:
    HashTable();
    HashTable(unsigned size);
    virtual ~HashTable();
    void Insert(Bid bid);
    void PrintAll();
    void Remove(string bidId);
    Bid Search(string bidId);
};