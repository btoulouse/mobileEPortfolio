class BinarySearchTree {

private:
    Node* root;

    void addNode(Node* node, Bid bid);
    void inOrder(Node* node);
    Node* removeNode(Node* node, string bidId);
    Node* minVal(Node* node);

public:
    BinarySearchTree();
    virtual ~BinarySearchTree();
    void InOrder();
    void Insert(Bid bid);
    void Remove(string bidId);
    Bid Search(string bidId);
};

void BinarySearchTree::Insert(Bid bid) {

	if (root == nullptr)
	{
		root = new Node(bid);
	}
	else
	{
		this->addNode(root, bid);
	}
}

void BinarySearchTree::addNode(Node* node, Bid bid) {

	if (node->bid.bidId.compare(bid.bidId) > 0)
	{
		if(node->left == nullptr)
		{
		node->left = new Node(bid);
		}
		else
		{
			this -> addNode(node -> left, bid);
		}
	}
	else
	{
		if (node -> right == nullptr)
		{
			node -> right = new Node(bid);
		}
		else
		{
			this -> addNode(node -> right, bid);
		}
	}

}