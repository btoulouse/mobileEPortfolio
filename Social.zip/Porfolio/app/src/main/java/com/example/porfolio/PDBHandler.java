package com.example.porfolio;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class PDBHandler extends SQLiteOpenHelper{

    // database name and version
    private static final int DB_VER = 1;
    private static final String DB_NAME = "pName.db";

    // table
    public static final String TABLE_PORT = "Portfolios";

    // columns
    public static final String COLUMN_ID = "id";
    public static final String COLUMN_NAME = "name";
    public static final String COLUMN_PHONE = "phone";
    public static final String COLUMN_ADDRESS = "address";
    public static final String COLUMN_EMAIL = "email";
    public static final String COLUMN_FACE = "facebook";

    // constructor
    public PDBHandler(Context context, String name,
                        SQLiteDatabase.CursorFactory factory, int version)
    {         super(context, DB_NAME, factory, DB_VER);     }

    // This method creates the User table when the DB is initialized.
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_PORT_TABLE = "CREATE TABLE " +
                TABLE_PORT + "(" +
                COLUMN_ID + " INTEGER PRIMARY KEY," +
                COLUMN_NAME + " TEXT," +
                COLUMN_PHONE + " INTEGER," +
                COLUMN_ADDRESS + " TEXT," +
                COLUMN_EMAIL + " TEXT," +
                COLUMN_FACE + " TEXT" + ")";

        db.execSQL(CREATE_PORT_TABLE);     }

    // This method closes an open DB if a new one is created.
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_PORT);
        onCreate(db);
    }

    // This method is used to add a User record to the database.
    public void addUser(Porfolio user) {
        ContentValues values = new ContentValues();
        values.put(COLUMN_NAME, user.getName());
        values.put(COLUMN_PHONE, user.getPhone());
        values.put(COLUMN_ADDRESS, user.getAddress());
        values.put(COLUMN_EMAIL, user.getEmail());
        values.put(COLUMN_FACE, user.getFace());

        SQLiteDatabase db = this.getWritableDatabase();

        db.insert(TABLE_PORT, null, values);
        db.close();
    }

    // implements the search/find functionality
    public Porfolio searchUser(String userName) {
        String query = "SELECT * FROM " +
                TABLE_PORT + " WHERE " + COLUMN_NAME +
                " = \"" + userName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        Porfolio user = new Porfolio();

        if (cursor.moveToFirst()) {
            cursor.moveToFirst();
            user.setID(Integer.parseInt(cursor.getString(0)));
            user.setName(cursor.getString(1));
            user.setPhone(cursor.getString(2));
            user.setAddress(cursor.getString(3));
            user.setEmail(cursor.getString(4));
            user.setFace(cursor.getString(5));
            cursor.close();

        } else {
            user = null;
        }

        db.close();
        return user;
    }

    // implements the delete User functionality
    public boolean deleteUser(String userName) {
        boolean result = false;

        String query = "SELECT * FROM " + TABLE_PORT +
                " WHERE " + COLUMN_NAME + " = \"" + userName + "\"";

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        Porfolio dog = new Porfolio();

        if (cursor.moveToFirst()) {
            dog.setID(Integer.parseInt(cursor.getString(0)));
            db.delete(TABLE_PORT, COLUMN_ID + " = ?",
                    new String[] { String.valueOf(dog.getID())});

            cursor.close();
            result = true;
        }
        db.close();
        return result;
    }
}