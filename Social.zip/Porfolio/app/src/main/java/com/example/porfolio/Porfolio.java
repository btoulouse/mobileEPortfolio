package com.example.porfolio;

public class Porfolio {

    // Variables
    private int id;
    private String name;
    private String pass;
    private String phone;
    private String address;
    private String email;
    private String face;

    //empty constructor
    public Porfolio() {}

    // Constructor with variables
    public Porfolio(String name, String phone, String address, String email, String face) {
        this.name = name;
        this.phone = phone;
        this.address = address;
        this.email = email;
        this.face = face;
    }

    public Porfolio(String pass) {
        this.pass = pass;
    }

    // Mutators
    public void setID(int id) { this.id = id; }
    public void setName(String name) {this.name = name;}
    public void setPass(String pass) {this.pass = pass;}
    public void setPhone(String phone) {this.phone = phone;}
    public void setAddress(String address) {this.address = address;}
    public void setEmail(String email) {this.email = email;}
    public void setFace(String face) {this.face = face;}

    // Accessors
    public int getID() { return this.id; }
    public String getName() {return this.name;}
    public String getPass() {return this.pass;}
    public String getPhone() {return this.phone;}
    public String getAddress() {return this.address;}
    public String getEmail() {return this.email;}
    public String getFace() {return this.face;}
}
