package com.example.porfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class PHome extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_p_home);

        // Create Button Press
        Button mButton = (Button) findViewById(R.id.button11);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PHome.this, CreateContent.class));
            }
        });

        // Create Button Press
        Button qButton = (Button) findViewById(R.id.button15);
        qButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PHome.this, MapsActivity.class));
            }
        });
        // View Button Press
        Button vButton = (Button) findViewById(R.id.button10);
        vButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PHome.this, Search.class));
            }
        });
        // View Button Press
        Button lButton = (Button) findViewById(R.id.button16);
        lButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(PHome.this, LinkedActivity.class));
            }
        });
    }

}
