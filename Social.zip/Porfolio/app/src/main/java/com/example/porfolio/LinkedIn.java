package com.example.porfolio;



// This sample code will make a request to LinkedIn's API to retrieve and print out some
// basic profile information for the user whose access token you provide.

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonReader;
import javax.net.ssl.HttpsURLConnection;

public class LinkedIn {

    public static void main(String[] args) {
        String profileUrl = "https://api.linkedin.com/v2/me";

        // API token
        String accessToken = "XgntcBtbDJ0mkNqP";

// saves profile info to string
        try {
            JsonObject profileData = LinkedIn.sendGetRequest(profileUrl, accessToken);
            System.out.println(profileData.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
// function to send request to LinkedIn, returns as JsonObject
    private static JsonObject sendGetRequest(String urlString, String accessToken) throws Exception {
        URL url = new URL(urlString);
        HttpsURLConnection con = (HttpsURLConnection)url.openConnection();

        con.setRequestMethod("GET");
        con.setRequestProperty("Authorization", "Bearer " + accessToken);
        con.setRequestProperty("cache-control", "no-cache");
        con.setRequestProperty("X-Restli-Protocol-Version", "2.0.0");

        BufferedReader br = new BufferedReader(new InputStreamReader(con.getInputStream()));
        StringBuilder jsonString = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) {
            jsonString.append(line);
        }
        br.close();

        JsonReader jsonReader = Json.createReader(new StringReader(jsonString.toString()));
        JsonObject jsonObject = jsonReader.readObject();

        return jsonObject;
    }
}