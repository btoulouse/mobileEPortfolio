package com.example.porfolio;

        import androidx.appcompat.app.AppCompatActivity;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.View;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.TextView;
        import android.widget.Toast;

public class CreatePorfolio extends AppCompatActivity {

    TextView idView;
    TextView nameView;
    EditText nameBox;
    EditText phoneBox;
    EditText addressBox;
    EditText emailBox;
    EditText faceBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_porfolio);

        // Sets user entered input to variables
        idView = (TextView) findViewById(R.id.userID);
        nameView = (TextView) findViewById(R.id.userName);
        nameBox = (EditText) findViewById(R.id.userName);
        phoneBox = (EditText) findViewById(R.id.userPhone);
        addressBox = (EditText) findViewById(R.id.userAddress);
        emailBox = (EditText) findViewById(R.id.userEmail);
        faceBox = (EditText) findViewById(R.id.userFace);

        final PDBHandler dbHandler = new PDBHandler(this, null, null, 1);

        // ADD USER  Button*************************
        Button aButton = (Button) findViewById(R.id.addUser);
        aButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               Porfolio user = new Porfolio(nameBox.getText().toString(),phoneBox.getText().toString(),
                       addressBox.getText().toString(), emailBox.getText().toString(), faceBox.getText().toString());

                dbHandler.addUser(user);
                nameBox.setText("");
                phoneBox.setText("");
                addressBox.setText("");
                emailBox.setText("");
                faceBox.setText("");
            }
        });
        // DELETE USER FROM SQLite ****************************
        Button dButton = (Button) findViewById(R.id.button4);
        dButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                boolean result = dbHandler.deleteUser(nameBox.getText().toString());

                if (result)
                {
                    idView.setText("User Deleted");
                    nameBox.setText("");
                }
                else
                    idView.setText("User not found.");
            }
        });

        final Button sButton = (Button) findViewById(R.id.button5);
        sButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Porfolio user = dbHandler.searchUser(nameBox.getText().toString());
               // showToast(user.getPass());
                if (user != null) {
                    startActivity(new Intent(CreatePorfolio.this, PHome.class));
                } else {
                    nameView.setText("User not found.");
                }
            }
        });
    }

    // Used for testing!! **
    private void showToast (String text) {
        Toast.makeText(CreatePorfolio.this, text, Toast.LENGTH_SHORT).show();
    }
}
