package com.example.porfolio;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    private static final String FILE_NAME = "example.txt";

    EditText mEditText;
    EditText pEditText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Sets user entered text to variable
        mEditText = findViewById(R.id.edit_text);
        pEditText = findViewById(R.id.editText);

    }

    public void save(View v) {
        //converts user entered text to string
        String name = mEditText.getText().toString();
        String pass = pEditText.getText().toString();
        String nLine = "\n";
        FileOutputStream fos = null;

        try {
            // Writes to file
            FileWriter myOutWriter = new FileWriter(getFilesDir() + "/" + FILE_NAME, true);
            myOutWriter.write(name);
            myOutWriter.write(pass);
            myOutWriter.write(nLine);
            myOutWriter.close();
            // CLeares boexs
            mEditText.getText().clear();
            pEditText.getText().clear();
            // confirms path and that file has been written to
            Toast.makeText(this, "Saved to " + getFilesDir() + "/" + FILE_NAME,
                    Toast.LENGTH_LONG).show();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try {
                    fos.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    public void load(View v) {
        FileInputStream fis = null;
        // user entered text to string
        String name = mEditText.getText().toString();
        String pass = pEditText.getText().toString();
        try {
            fis = openFileInput(FILE_NAME);
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            StringBuilder sb = new StringBuilder();
            String text;
            //loop through file
            while ((text = br.readLine()) != null) {
                sb.append(text);
                // checks user entered text against file if found go to new page
                if (text.equals(name + pass))
                {
                    startActivity(new Intent(MainActivity.this, CreatePorfolio.class));
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    // For testing!!!!
    private void showToast (String text) {
        Toast.makeText(MainActivity.this, text, Toast.LENGTH_SHORT).show();
    }
}

