package com.example.porfolio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class LinkedActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linked_in);
        // LinkedIn Button Press
        Button lButton = (Button) findViewById(R.id.button);
        lButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new LinkedIn();
            }
        });
    }
}
