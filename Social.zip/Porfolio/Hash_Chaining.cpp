void HashTable::Insert(Bid bid) {

   unsigned key = hash(atoi(bid.bidId.c_str()));

   // search for node with the key value

   Node* prevNode = &(myNodes.at(key));

   if (prevNode == nullptr) {
       Node* nextNode = new Node(bid, key);
       myNodes.insert(myNodes.begin() + key, (*nextNode));
   } else {
       // if node is found
       if (prevNode->key == UINT_MAX) {
           prevNode->key = key;
           prevNode->bid = bid;
           prevNode->nextNodePtr = nullptr;
       } else {
           // if not found, find the next node available
           while (prevNode->nextNodePtr != nullptr) {
               prevNode = prevNode->nextNodePtr;
           }
       }
   }
}