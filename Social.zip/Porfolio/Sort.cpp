int partition(vector<Bid>& bids, int begin, int end)
{

	Bid temp;
	bool done = false;

	// sets mid to pivot
	int mid = begin + (end - begin) / 2;
	Bid pivot = bids.at(mid);
	int l = begin;
	int h = end;

	while (!done)
	{
		// Incrament l while bids[l] < pivot
		while (bids.at(l).title.compare(pivot.title) == -1)
		{
			++l;
		}
		// decrement h while bids[h] > pivot
		while (pivot.title.compare(bids.at(h).title) == -1)
		{
			--h;
		}
		// checks for 1 or 0 elements remaning, if true, return h
		if (l >= h)
		{
			done = true;
		}
		// if false swap bids[l] with bids[h]
		else
		{
			temp = bids.at(l);
			bids.at(l) = bids.at(h);
			bids.at(h) = temp;

			++l;
			--h;
		}
	}

	return h;
}

void quickSort(vector<Bid>& bids, int begin, int end) {
		// already sorted
		if ( begin >= end)
		{
			return;
		}

		int pivot = partition(bids, begin , end);

		quickSort(bids, begin, pivot);
		quickSort(bids, pivot + 1, end);

	return;
}