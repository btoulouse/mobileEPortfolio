Bid LinkedList::Search(string bidId) {
    // FIXME (7): Implement search logic
	node* curNode = head;
	node* temp = new node;
	temp -> data.bidId = "";

	while (curNode != nullptr) // loops through entire list
	{
		cout << curNode -> data.bidId << endl;
		if (curNode -> data.bidId == bidId) // checks curent node 
		{
			return curNode -> data;
		}
		curNode = curNode -> nextNode;
	}
	return temp-> data;
}